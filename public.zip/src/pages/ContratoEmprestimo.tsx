import { useNavigate } from 'react-router-dom';

function ContratosEmprestimos() {
  const navigate = useNavigate();
  return (

    <>
      <header>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <button
            type="button"
            onClick={() => navigate(-1)}
            className="cursor-pointer text-sm font-semibold text-gray-900 hover:underline"
          >
            Voltar
          </button>
          <h1 className="text-4xl font-thin leading-tight tracking-tight text-gray-800">Contratos de Emprestimos</h1>
        </div>
      </header>
      <main>
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          {/* Your content */}
        </div>
      </main>
    </>

  );
}

export default ContratosEmprestimos;

