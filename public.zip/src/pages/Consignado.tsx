import React, { useState } from 'react';
import Cards from '../components/Cards';
import Modal from '../components/Modal';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCalendarAlt, faFileAlt, faFileContract } from '@fortawesome/free-solid-svg-icons';

function Consignado() {

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState<React.ReactNode | null>(null);
  const [modalMaxWidth, setModalMaxWidth] = useState<string>('sm:max-w-4xl'); // Default width

  const openModal = (content: React.ReactNode, maxWidth: string) => {
    setModalContent(content);
    setModalMaxWidth(maxWidth);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setModalContent(null);
  };

  const navigate = useNavigate();

  return (
    <>
      <header>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="cursor-pointer text-sm font-semibold text-gray-900 hover:underline"
          >
            Voltar
          </button>
          <h1 className="text-4xl font-thin leading-tight tracking-tight text-gray-800">Consignado</h1>
        </div>
      </header>
      <main>
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 grid grid-cols-2 gap-16">
          <div className='flex flex-col gap-4'>
            <div className="h-[300px] w-100 overflow-hidden rounded-xl relative">
              <img
                className="object-contain object-center absolute inset-0 w-full h-full"
                src="consignado.svg"
                alt="Consignado"
              />
            </div>
            <div className='flex flex-col gap-4'>
              <p>
                Empregador, verifique aqui se algum trabalhador da sua empresa contratou Empréstimo Consignado do Trabalhador.
              </p>
              <div className='bg-dpPure-0 p-4 rounded-lg border border-1 border-dpGray-5'>
                <p>Aqui você pode:</p>
                <ul className='list-disc list-outside ms-5 mt-2'>
                  <li>acessar o calendário do consignado;</li>
                  <li>efetuar o download de arquivo com os empréstimos consignados do seu trabalhador;</li>
                  <li>consultar informações sobre os empréstimos contratados pelso seus trabalhadores.</li>
                </ul>
              </div>

            </div>

            <div className="flex gap-2">

              <button type="button"
                onClick={() => openModal(
                  <div className='flex flex-col gap-8'>
                    <div className='flex flex-col items-center'>
                      <img src="modal1_1.svg" className='max-w-[200px]' />
                      <p>Empréstimo Consignado do Trabalhador</p>
                    </div>
                    <div>
                      <p className="font-bold mt-4 mb-2">1. O que é?</p>
                      <div className='grid grid-cols-2 gap-4'>
                        <p>É o programa do governo federal que permite que trabalhadores com vínculos de trabalho ativos tenham acesso ao crédito bancário com taxas de juros mais baixas.</p>
                        <p className='bg-dpOrangeVivid-30 p-4 rounded-md text-dpPure-0'>Os empregadores, domésticos ou empresas, serão responsáveis por efetuar os descontos no contracheque do trabalhador e lançar as rubricas relacionadas no eSocial ou FGTS Digital.</p>
                      </div>
                    </div>
                    <div>
                      <p className="font-bold mt-4 mb-2">2. Como funciona para o trabalhador?</p>
                      <div className='grid grid-cols-4 gap-4'>
                        <figure><img src="modal1_2.svg" /><figcaption>Trabalhador simula empréstimo e solicita propostas na Carteira de Trabalho Digital.</figcaption></figure>
                        <figure><img src="modal1_3.svg" /><figcaption>Instituições financeiras enviam propostas personalizadas em até 24h.</figcaption></figure>
                        <figure><img src="modal1_4.svg" /><figcaption>Trabalhador avalia as propostas de empréstimo recebidas.</figcaption></figure>
                        <figure><img src="modal1_5.svg" /><figcaption>Trabalhador faz a contratação nos canais oferecidos pelas instituições financeiras.</figcaption></figure>
                      </div>
                    </div>
                    <div>
                      <p className="font-bold mt-4 mb-2">3. Como serei informado que um trabalhador da minha empresa contratou o Consignado?</p>
                      <div className='grid grid-cols-2 gap-4'>
                        <p>Empregador será notificado pelo sistema DET (Domicílio Eletrônico Trabalhista) que trabalhadores da sua Empresa contrataram o Empréstimo Consignado do Trabalhador.</p>
                        <div className="h-100 w-100 overflow-hidden relative min-h-[150px]">
                          <img
                            className="object-contain object-center absolute inset-0 w-full h-full"
                            src="modal1_6.svg"
                            alt="Consignado"
                          />
                        </div>

                      </div>
                    </div>
                    <div>
                      <p className="font-bold mt-4 mb-2">4. O que o empregador precisa fazer?</p>
                      <div className='grid grid-cols-4 gap-4'>
                        <figure><img src="modal1_7.svg" /><figcaption>Acesse, mensalmente, o Portal Emprega Brasil e consultar as informações de empréstimos consignados dos seus trabalhadores.</figcaption></figure>
                        <figure><img src="modal1_8.svg" /><figcaption>Baixe o arquivo de empréstimos da competência no seu formato de preferência.</figcaption></figure>
                        <figure><img src="modal1_9.svg" /><figcaption>Insira as informações do arquivo na sua folha de pagamento para proceder o desconto no contracheque.</figcaption></figure>
                        <figure><img src="modal1_10.svg" /><figcaption>Realize o lançamento das rubricas na plataforma FGTS digital. Pague as guias.</figcaption></figure>
                      </div>
                    </div>
                    <div>
                      <p className="font-bold mt-4 mb-2">5. O trabalhador com empréstimo consignado pode ser demitido ?</p>
                      <p>Sim. Em caso de desligamento deste trabalhador a Lei XXX permite que parte das verbas rescisórias seja utilizada para descontar as parcelas do empréstimo.</p>
                      <p>Caso o trabalhador seja reempregado, será feita a portabilidade automática do seu empréstimo consignado para o novo empregador efetuar os descontos devidos.</p>
                    </div>
                  </div>,
                  'sm:max-w-4xl'
                )}
                className="rounded-full bg-dpBlueWarmVivid-60 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-dpBlueWarmVivid-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-dpBlueWarmVivid-60">
                O que eu preciso fazer?
              </button>
            </div>
          </div>
          <div className="flex flex-col gap-4">
            <Cards
              name="Consultar calendário"
              // role="Co-Founder / CEO"
              icon={faCalendarAlt}
              onClick={() => openModal(
                <div className='flex flex-col gap-8'>
                  <p className='text-2xl font-thin'>Consultar calendário</p>
                  <div className='flex justify-around'>
                    <FontAwesomeIcon icon={faCalendarAlt} className="h-8 w-8 text-dpBlueWarmVivid-50" />
                    <div>
                      <p className='text-xs uppercase'>Competência atual</p>
                      <p className='font-semibold'>JUN 2024</p>
                    </div>
                    <div>
                      <p className='text-xs uppercase'>Início</p>
                      <p className='font-semibold'>21/05/2024</p>
                    </div>
                    <div>
                      <p className='text-xs uppercase'>Fim</p>
                      <p className='font-semibold'>20/06/2024</p>
                    </div>
                  </div>
                  <p>As datas de início e fim delimitam os empréstimos consignados que são considerados daquela competência. Ou seja, os empréstimos consignados contratados pelos trabalhadores entre <strong>21/05/2024</strong> e <strong>20/06/2024</strong> são considerados da competência atual <strong>JUN 2024</strong>.</p>
                  <div className='border-t border-dpGray-20'></div>
                  <div>
                    <p className='text-xl font-thin'>Quer consultar competências anteriores?</p>
                    <p>Selecione a competência que você deseja consultar:</p>
                    <div className='flex justify-around gap-8 mt-4'>
                      <div className='w-full'>
                        <label htmlFor="ano" className="block text-sm font-medium leading-6 text-gray-900">
                          Ano
                        </label>
                        <select
                          id="ano"
                          name="ano"
                          defaultValue="2024"
                          className="mt-2 block w-full rounded-md border-0 py-1.5 pl-3 pr-10 text-gray-900 ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-indigo-600 sm:text-sm sm:leading-6"
                        >
                          <option>2024</option>
                          <option>2023</option>
                          <option>2022</option>
                          <option>2021</option>
                          <option>2020</option>
                          <option>2019</option>
                          <option>2018</option>
                          <option>2017</option>
                          <option>2016</option>
                          <option>2015</option>
                          <option>2014</option>
                        </select>
                      </div>
                      <div className='w-full'>
                        <label htmlFor="mes" className="block text-sm font-medium leading-6 text-gray-900">
                          Mês
                        </label>
                        <select
                          id="mes"
                          name="mes"
                          defaultValue="Agosto"
                          className="mt-2 block w-full rounded-md border-0 py-1.5 pl-3 pr-10 text-gray-900 ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-indigo-600 sm:text-sm sm:leading-6"
                        >
                          <option>Janeiro</option>
                          <option>Fevereiro</option>
                          <option>Março</option>
                          <option>Abril</option>
                          <option>Maio</option>
                          <option>Junho</option>
                          <option>Julho</option>
                          <option>Agosto</option>
                          <option>Setembro</option>
                          <option>Outubro</option>
                          <option>Novembro</option>
                          <option>Dezembro</option>

                        </select>
                      </div>
                    </div>
                    
                  </div>
                  <div className='flex justify-end'>
                      <button type="button" className="rounded-full bg-dpBlueWarmVivid-60 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-dpBlueWarmVivid-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-dpBlueWarmVivid-60">
                        Consultar
                      </button>
                    </div>

                </div>,
                'sm:max-w-2xl'
              )}
            />
            <Cards
              name="Arquivo de empréstimo"
              // role="Co-Founder / CEO"
              icon={faFileAlt}
              url="/arquivos"
            />
            <Cards
              name="Consultar contrato e empréstimo"
              // role="Co-Founder / CEO"
              icon={faFileContract}
              url="/contratos"
            />
          </div>
        </div>
      </main>

      {/* Modal */}
      <Modal isOpen={isModalOpen} onClose={closeModal} maxWidth={modalMaxWidth}>
        {modalContent}
      </Modal>
    </>
  );
}

export default Consignado;