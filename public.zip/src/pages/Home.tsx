import Cards from "../components/Cards";
import { faCirclePlus, faBoxesPacking, faFileLines, faBuilding, faChildren, faChartPie, faCoins } from '@fortawesome/free-solid-svg-icons';

function Home() {
  return (

    <>
    <header>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-thin leading-tight tracking-tight text-gray-800">Cadastro e gestão de vagas</h1>
        </div>
      </header>
      <main>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <Cards
              name="Cadastrar vagas de emprego"
              icon={faCirclePlus}
              url="/"
              isVertical={true}
            />
        <Cards
              name="Vagas cadastradas"
              icon={faFileLines}
              url="/"
              isVertical={true}
            />
            <Cards
              name="Processamento em lote"
              icon={faBoxesPacking}
              url="/"
              isVertical={true}
            />
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h1 className="text-2xl font-thin leading-tight tracking-tight text-gray-800">Outros serviços</h1>
        </div>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <Cards
              name="Informações empregador"
              icon={faBuilding}
              url="/"
            />
        <Cards
              name="Igualdade salarial"
              icon={faChildren}
              url="/"
            />
            <Cards
              name="CAGED/RAIS"
              icon={faChartPie}
              url="/"
            />
        <Cards
              name="Consignado do trabalhador"
              icon={faCoins}
              url="/consignado"
            />
        </div>
      </main>
    </>

  );
}

export default Home;