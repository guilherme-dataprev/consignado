import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Consignado from './pages/Consignado';
import Arquivos from './pages/ArquivosEmprestimos';
import Contratos from './pages/ContratoEmprestimo';
import ApplicationShell from './components/ApplicationShell';
import Home from './pages/Home';

function App() {
  return (
    <Router>
      <ApplicationShell>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/consignado" element={<Consignado />} />
          <Route path="/arquivos" element={<Arquivos />} />
          <Route path="/contratos" element={<Contratos />} />
        </Routes>
      </ApplicationShell>
    </Router>
  );
}

export default App;
