import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';

type CardsProps = {
  name: string;
  role?: string;
  icon: IconDefinition;
  onClick?: () => void;
  url?: string;
  isVertical?: boolean;  // New prop to control the layout
};

const Cards: React.FC<CardsProps> = ({ name, role, icon, onClick, url, isVertical = false }) => {
  const navigate = useNavigate();

  const handleClick = () => {
    if (onClick) {
      onClick(); // Open modal
    } else if (url) {
      navigate(url); // Navigate to another page
    }
  };

  return (
    <div
      onClick={handleClick}
      className={`cursor-pointer relative flex ${
        isVertical ? 'flex-col items-start' : 'items-center'
      } gap-4 rounded-sm border border-dpGray-10 bg-white px-6 py-5 shadow-sm focus-within:ring-2 focus-within:ring-blue-500 focus-within:ring-offset-2 hover:border-dpGray-20`}
    >
      <div className="flex-shrink-0">
        <FontAwesomeIcon icon={icon} className="h-8 w-8 text-dpBlueWarmVivid-50" />
      </div>
      <div className="min-w-0 flex-1">
        <span className="focus:outline-none">
          <p className="text-sm font-medium text-gray-900">{name}</p>
          <p className="truncate text-sm text-gray-500">{role}</p>
        </span>
      </div>
    </div>
  );
};

export default Cards;
